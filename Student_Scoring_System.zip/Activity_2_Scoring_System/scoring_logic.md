# Student Scoring System: Logic & Thresholds

## 1. Overview
This scoring system transforms raw student data into actionable metrics. By calculating five specific scores, we can categorize students into **Green (Excellent)**, **Blue (Stable)**, **Yellow (At-Risk)**, and **Red (Critical)** tiers to prioritize mentoring interventions.

## 2. Calculated Scores

### A. Academic Performance Score (APS)
Measures traditional academic success based on grades and participation.
*   **Formula**: `(GPA_Normalized * 50%) + (Attendance * 25%) + (Assignments * 25%)`
*   **Scale**: 0 - 100
*   **Rationale**: GPA is the primary indicator, but attendance and assignment completion are leading indicators of future performance.

### B. Wellness & Wellbeing Score (WWS)
A holistic measure of mental and physical health.
*   **Formula**: `(Stress_Inverse * 40%) + (Mental_Wellbeing * 40%) + (Sleep_Score * 20%)`
*   **Scale**: 0 - 100
*   **Logic**:
    *   *Stress_Inverse*: Lower stress creates a higher score.
    *   *Sleep_Score*: 6-9 hours = 100 (Optimal), <5 hours = 40 (Poor).
    *   *Wellbeing*: Self-reported subjective score.

### C. Productivity & Time Management Score (PTMS)
Measures the student's ability to focus and engage.
*   **Formula**: `(Productivity * 40%) + (Low_Distractions * 30%) + (Engagement * 30%)`
*   **Scale**: 0 - 100
*   **Rationale**: High productivity combined with low distractions indicates strong executive function.

### D. Career Readiness Score (CRS)
Indicates how prepared a student is for the professional world.
*   **Formula**: `Average(Career_Clarity, Skill_Readiness)`
*   **Scale**: 0 - 100
*   **Rationale**: Balances "knowing what you want to do" (Clarity) with "knowing how to do it" (Skills).

### E. Student Readiness Index (SRI)
The **Master Metric**. A composite index used for final classification.
*   **Formula**: 
    *   35% Academic (APS)
    *   25% Career (CRS)
    *   20% Productivity (PTMS)
    *   20% Wellbeing (WWS)
*   **Rationale**: Academics and Career are the primary outputs of education, but Wellbeing and Productivity are the "engines" that sustain them.

## 3. Classification Thresholds (The "SRI" Tiers)

Students are categorized based on their **Student Readiness Index (SRI)**:

| Category | Color Code | SRI Range | Description | Recommended Action |
| :--- | :--- | :--- | :--- | :--- |
| **Ready** | 🟢 **Green** | **80 - 100** | High performing, balanced, career-ready. | Career accelerator programs, peer mentoring roles. |
| **Stable** | 🔵 **Blue** | **65 - 79** | Good academic standing, minor gaps. | Regular check-ins, skill-building workshops. |
| **At Risk** | 🟡 **Yellow** | **50 - 64** | Struggling in one or more areas. | **Targeted Intervention**: Academic counseling or stress management. |
| **Critical** | 🔴 **Red** | **< 50** | Severe academic or wellbeing issues. | **Immediate Action**: 1-on-1 Mentoring, Urgent Wellbeing Check. |
