
import pandas as pd
import numpy as np

def calculate_sleep_score(hours):
    """
    Scoring logic for sleep:
    - 6 to 9 hours = 100 (Optimal)
    - 5 to 6 or 9 to 10 = 75 (Ok)
    - < 5 or > 10 = 40 (Poor)
    """
    if 6 <= hours <= 9:
        return 100
    elif 5 <= hours < 6 or 9 < hours <= 10:
        return 75
    else:
        return 40

def main():
    # 1. Load Data
    try:
        df = pd.read_csv("students.csv")
    except FileNotFoundError:
        print("Error: students.csv not found.")
        return

    # 2. Compute Academic Performance Score (APS)
    # Formula: 50% GPA (normalized to 100), 25% Attendance, 25% Assignments
    df['APS'] = (df['gpa'] * 10 * 0.50) + \
                (df['attendance'] * 0.25) + \
                (df['assignments_completion'] * 0.25)

    # 3. Compute Wellness & Wellbeing Score (WWS)
    # Components: 
    # - Stress (Inverse: Low stress is good): (10 - stress) * 10
    # - Mental Wellbeing: wellbeing * 10
    # - Sleep: Custom function
    df['stress_inv_score'] = (10 - df['stress_level']) * 10
    df['wellbeing_norm'] = df['mental_wellbeing'] * 10
    df['sleep_score'] = df['sleep_hours'].apply(calculate_sleep_score)
    
    # Weights: 40% Stress, 40% Wellbeing, 20% Sleep
    df['WWS'] = (df['stress_inv_score'] * 0.40) + \
                (df['wellbeing_norm'] * 0.40) + \
                (df['sleep_score'] * 0.20)

    # 4. Compute Productivity & Time Management Score (PTMS)
    # Components:
    # - Productivity Score (normalized)
    # - Distractions (Inverse)
    # - Engagement Score
    df['prod_norm'] = df['productivity_score'] * 10
    df['distract_inv'] = (10 - df['distractions']) * 10
    
    # Weights: 40% Productivity, 30% Low Distractions, 30% Engagement
    df['PTMS'] = (df['prod_norm'] * 0.40) + \
                 (df['distract_inv'] * 0.30) + \
                 (df['engagement_score'] * 0.30)

    # 5. Compute Career Readiness Score (CRS)
    # Components: Career Clarity, Skill Readiness (both 1-10 scale)
    df['CRS'] = ((df['career_clarity'] * 10) + (df['skill_readiness'] * 10)) / 2

    # 6. Compute Student Readiness Index (SRI)
    # Weighted average of all scores
    # Priority on Academics and Career for "Readiness"
    df['SRI'] = (df['APS'] * 0.35) + \
                (df['CRS'] * 0.25) + \
                (df['PTMS'] * 0.20) + \
                (df['WWS'] * 0.20)

    # 7. Classification
    def categorize(sri):
        if sri >= 80:
            return 'Green'  # Ready / Excellent
        elif sri >= 65:
            return 'Blue'   # Stable / Good
        elif sri >= 50:
            return 'Yellow' # At Risk / Needs Improvement
        else:
            return 'Red'    # Critical / Intervention Needed

    df['Category'] = df['SRI'].apply(categorize)

    # Round scores for readability
    score_cols = ['APS', 'WWS', 'PTMS', 'CRS', 'SRI']
    df[score_cols] = df[score_cols].round(2)

    # Clean up intermediate columns
    final_df = df.drop(columns=['stress_inv_score', 'wellbeing_norm', 'sleep_score', 'prod_norm', 'distract_inv'])

    # 8. Save
    output_filename = "students_with_scores.csv"
    final_df.to_csv(output_filename, index=False)
    print(f"Successfully created {output_filename} with {len(final_df)} records.")
    
    # 9. Verify / Preview
    print("\nSample Output (Top 5):")
    print(final_df[['student_id', 'APS', 'WWS', 'PTMS', 'CRS', 'SRI', 'Category']].head())
    print("\nCategory Distribution:")
    print(final_df['Category'].value_counts())

if __name__ == "__main__":
    main()
